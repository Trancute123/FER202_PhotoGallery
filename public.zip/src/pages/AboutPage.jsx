import React from "react";

export default function AboutPage() {
  return <h1>Giới thiệu (About Page)</h1>;
}
