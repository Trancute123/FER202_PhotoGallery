import React from "react";

export default function ExplorePage() {
  return <h1>Trang Khám Phá (Explore)</h1>;
}
